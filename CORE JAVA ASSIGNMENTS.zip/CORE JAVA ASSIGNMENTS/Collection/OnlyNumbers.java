import java.util.ArrayList;
import java.lang.RuntimeException;

class OnlyNumbers {
	public static void main(String[] args){
		// Only allow addition of int, float, and double into the array list
		
		// Creating an array list of double type
		ArrayList<Double> al = new ArrayList<>();
		
		try{
			
			
			add(al, 5);
			add(al, 4.54);
			add(al, 43.5353);
			add(al, "Name");
		} catch(Exception e){
			e.printStackTrace();
		}
		
		System.out.print(al);
	}
	
	
	// Created custom static add method
	// int, float --> converted into Double -> added to arraylist
	// Double -> added directly
	// String -> throws NotANumber Exception
	
	static void add(ArrayList<Double> al, int a){
		Double input = Double.valueOf(a);
		al.add(input);
	}
	
	static void add(ArrayList<Double> al, float a){
		Double input = Double.valueOf(a);
		al.add(input);
	}
	
	static void add(ArrayList<Double> al, double a){
		al.add(a);
	}
	
	static void add(ArrayList<Double> al, String a){
		throw new NotANumberException("Must enter a number of either int, float or double type");
	}
}


// Custom NotANumberException
class NotANumberException extends RuntimeException{
		NotANumberException(String s){
			super(s);
		}
}

