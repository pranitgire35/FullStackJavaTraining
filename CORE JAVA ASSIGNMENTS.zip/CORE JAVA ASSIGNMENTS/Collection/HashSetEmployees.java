// Group of employee names in hashset and retrive them using iterator
import java.util.HashSet;
import java.util.Iterator;

class HashSetEmployees{
	public static void main(String[] args){
		// Creating hashSet for all employee
		HashSet<Employee> hsAllEmployees = new HashSet<>();
		
		// Creating employee objects
		Employee e1 = new Employee("Manish");
		Employee e2 = new Employee("Ram");
		Employee e3 = new Employee("Shyam");
		
		
		// Adding employees to hashSet
		hsAllEmployees.add(e1);
		hsAllEmployees.add(e2);
		hsAllEmployees.add(e3);
		
		// Iterating and printing all employees
		Iterator<Employee> itr = hsAllEmployees.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
	}
}


// Employee class
class Employee{
	private String name;
	
	Employee(){
		this.name = null;
	}
	
	Employee(String name){
		this.name = name;
	}
	
	public String toString(){
		return "Name: " +  this.name;
	}
}