// Vector to store employees objects
//use iterator and enumerations to list them

import java.util.Vector;
import java.util.Iterator;
import java.util.Enumeration;

class VectorEmployees{
	public static void main(String[] args){
		
		// Creating vector object of employee type
		Vector<Employee> allEmployees = new Vector();
		
		// Creating and adding employee
		Employee e1 = new Employee("Manish", "101");
		Employee e2 = new Employee("Rupesh", "102");
		
		allEmployees.add(e1);
		allEmployees.add(e2);
		
		
		// Listing using ListIterator
		Iterator<Employee> itr = allEmployees.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		
		
		System.out.println("");
		
		// Using Enumerations
		Enumeration en = allEmployees.elements();
		
		while(en.hasMoreElements()){
			System.out.println(en.nextElement());
		}
	}
}

// Employee class wit name and eId as instance variables
class Employee{
	private String name;
	private String eId;
	
	
	// Parameterized and non parameterized constructors
	Employee(){
		this.name = null;
		this.eId = null;
	}
	
	Employee(String name, String eId){
		this.name = name;
		this.eId = eId;
	}
	
	// to String method
	
	public String toString(){
		return "Name: " +  this.name + ", Id: " + this.eId + " ";
	}
}