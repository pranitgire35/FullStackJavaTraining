
import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ArrayList<Integer> a = new ArrayList<>();
		List<Integer> a = new ArrayList<>();
		a.add(35);
		a.add(47);
		a.add(20);
		
		for(Integer i : a) {
			System.out.println(i);
		}
	}

}