import java.util.HashSet;
import java.util.Iterator;

// Vector, lInkedlist,  stack
class HashSetDemo{
	public static void main(String[] args){
		HashSet<String> hs = new HashSet<>();
		
		hs.add("10");
		hs.add("20");
		hs.add("30");
		
		Iterator itr = hs.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next() + " ");
		}
		hs.remove("30");
		hs.add("40");
		hs.add("50");
		System.out.println(hs);
	}
}