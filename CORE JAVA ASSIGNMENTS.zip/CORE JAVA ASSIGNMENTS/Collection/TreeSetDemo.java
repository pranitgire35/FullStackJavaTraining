// Use treeSet to store string
// Operations - reverse elements , iterate elements, check if element exist or not
import java.util.TreeSet;
import java.util.Iterator;

class TreeSetDemo{
	public static void main(String[] args){
		TreeSet<String> ts = new TreeSet<>();
		
		
		// Adding elements to treeSet
		ts.add("10");
		ts.add("20");
		ts.add("Manish");
		ts.add("Yash");
		ts.add("Rupesh");
		
		
		// Using normal iterator to iterate throught the treeSet
		Iterator itr = ts.iterator();
		while(itr.hasNext()){
			System.out.print(itr.next() + " ");
		}
		
		System.out.println("");
		
		
		// Using descendingIterator to iterate through the treeSet in reverse order
		Iterator itr2 = ts.descendingIterator();
		while(itr2.hasNext()){
			System.out.print(itr2.next() + " ");
		}
		
		System.out.println("");
		
		// Checking if treeSet contains following strings
		System.out.println(ts.contains("Manish"));
		System.out.println(ts.contains("Himanshu"));
		System.out.println(ts.contains("10"));
	}
}