	import java.util.LinkedList;
import java.util.Iterator;


class LinkedListDemo{
	public static void main(String[] args){
		LinkedList<String> ll = new LinkedList<>();
		
		ll.add("Yash");
		ll.add("10");
		ll.add("20");
		ll.add("30");
		
		Iterator itr = ll.iterator();
		
		while(itr.hasNext()){
			System.out.print(itr.next() + " ");
		}
		
		ll.remove("20");
		ll.add("35");
		System.out.println(ll);
		
	}
}