import java.util.ArrayList;
import java.util.Vector;
import java.util.Iterator;

class VectorMonthsOfYear{
	public static void main(String[] args){
		// create an array list
		// add all months of the year
		// use an vector to show them
		
		ArrayList<String> year = new ArrayList<>();
		
		year.add("Jan");
		year.add("Feb");
		year.add("Mar");
		year.add("Apr");
		year.add("May");
		year.add("Jun");
		year.add("Jul");
		year.add("Aug");
		year.add("Sep");
		year.add("Oct");
		year.add("Nov");
		year.add("Dec");
		
		// Creating vector and adding all months from arraylist
		Vector<String> vecYear = new Vector<>();
		vecYear.addAll(year);
		
		// Iterating and printing the months
		Iterator itr = vecYear.iterator();
		while(itr.hasNext()){
			System.out.print(itr.next() + " ");
		}
		
		
	}
}