// class (H1, saveCountryName(name))

import java.util.HashSet;
import java.util.Iterator;

class CountryHashSet{
	
	public static void main(String[] args){
		
			// Creating object of countries class
			Countries c = new Countries();
			
			// Adding countries to it
			c.saveCountryName("India");
			c.saveCountryName("Ireland");
			c.saveCountryName("Germany");
			
			
			// Checking if hashSet contains the country passed as parameter
			System.out.println(c.getCountry("India"));
			System.out.println(c.getCountry("Germany"));
			
			System.out.println(c.getCountry("Russia")); // returns null
			
	}
}

// Class countries with hashSet h1 as instance variable
class Countries{
	private HashSet<String> H1;
	
	// Constructor
	Countries(){
		this.H1 = new HashSet<>();
	}
	
	
	// adding country to hashSet
	public void saveCountryName(String name){
		this.H1.add(name);
	}
	
	
	// getting country from hashSet
	public String getCountry(String name){
		Iterator itr = this.H1.iterator();
		while(itr.hasNext()){
			String c = (String)itr.next();
			if(c.equals(name)){
				return c;
			}
		}
		
		return null;
	}
}