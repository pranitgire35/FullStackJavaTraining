import java.util.Stack;
import java.util.Iterator;

class StackDemo

{
	public static void main(String[] args)

               {
		
            Stack<String> stk = new Stack<>();
		stk.push("10");
		stk.push("20");
		stk.push("30");
		
		Iterator itr = stk.iterator();
		while(itr.hasNext()){
			System.out.print(itr.next() + " ");
		}
		
		System.out.println("");
		System.out.println(stk.pop());
		System.out.println(stk.peek());
		System.out.println(stk);
	}
}
