import java.io.*

class Employee implements Serializable
{

int empId;
string empName;

Employee(int empId, String empName)

{

this.empId = empId;

this.empName = empName;

}

public string toString()

{

return empId + " " + empName;

}

}