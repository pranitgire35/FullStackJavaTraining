interface GeneralBank

{
		
	public Double getSavingsInterestRate();
	
	public Double getFixedInterestRate();
	
}

class SBIBank implements GeneralBank{

	private double savingRate;
	 
	private double fixedDepositRate;
	
	SBIBank(Double savingRate, Double fixedDepositRate){

		this.savingRate = savingRate;
		this.fixedDepositRate = fixedDepositRate;
	}
	
	public Double getSavingsInterestRate(){

		return this.savingRate;
	}
	
	public Double getFixedInterestRate(){

		return this.fixedDepositRate;
	}
}

class ICICIBank implements GeneralBank{

	private double savingRate;
	private double fixedDepositRate;
	
	ICICIBank(Double savingRate, Double fixedDepositRate){

		this.savingRate = savingRate;
		this.fixedDepositRate = fixedDepositRate;
	}
	
	public Double getSavingsInterestRate(){

		return this.savingRate;
	}
	
	public Double getFixedInterestRate(){

		return this.fixedDepositRate;
	}
}

class GeneralBank

    {

	public static void main(String[] args){

		SBIBank s = new SBIBank(3.5, 5.0);
		
		ICICIBank i = new ICICIBank(5.0, 7.5);
		
		System.out.println("ICICI Bank, savings Rate: " + i.getSavingsInterestRate() + ", fixedDepositRate : " + i.getFixedInterestRate());
		
		System.out.println("SBI Bank, savings Rate: " + s.getSavingsInterestRate() + ", fixedDepositRate : " + s.getFixedInterestRate());
	
	}
	
}