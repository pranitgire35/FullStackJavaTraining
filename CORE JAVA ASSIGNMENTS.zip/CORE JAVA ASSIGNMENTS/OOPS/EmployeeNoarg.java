import java.io.*;
  
class Emp implements Serializable 

{
    String name;
	String department;
	String designation;
    double salary;
  
	public Emp(String name, String department, String designation, double salary)
    
	{
        this.name = name;
        this.department = department;
        this.designation = designation;
        this.salary = salary;
    }


}

public class EmployeeNoarg 

{
	public static void printdata(Emp object1)
    
	{
        System.out.println("name = " + object1.name);
        System.out.println("department = " + object1.department);
        System.out.println("designation = " + object1.designation);
        System.out.println("salary = " + object1.salary);
    }
	
  	public static void main(String[] args)
    
	{
        Emp object = new Emp("Human", "Java", "employee", 101.0);
        String filename = "Yash.txt";
        
		try 
		
		{
            FileOutputStream file = new FileOutputStream(filename);
            ObjectOutputStream out = new ObjectOutputStream(file);
            out.writeObject(object);  
            out.close();
            file.close(); 
            System.out.println("before Deserialization.");
            printdata(object);            
        }
		
        catch (IOException ex) 
		
		{
            
			System.out.println("IOException is caught");
			
        }
        
		try 
		
		{    
            FileInputStream file = new FileInputStream(filename);
            ObjectInputStream in = new ObjectInputStream(file);
            object = (Emp)in.readObject(); 
            in.close();
            file.close();
            System.out.println("after Deserialization.");
            printdata(object);        
        }  
		
		catch (IOException ex) 
		
		{
            
			System.out.println("IOException is caught");
			
        }  
        
		catch (ClassNotFoundException ex) 
		
		{
            
			System.out.println("ClassNotFoundException" + " is caught");
			
        }
    }
}