import java.io.console;

class ConsoleDemo

{

    public static void main(String[] args)

    {

        String str;

        char ch[];

        Console ob = System.console();

        System.out.print("enter username");

        str = ob.readLine();

        System.out.print("enter password");

        ch = ob.readPassword();

        String a = String.valueof(ch);

        System.out.print("username : " + str + "password :" + ch);

        System.out.print("Actual password :" + a);

    }

}