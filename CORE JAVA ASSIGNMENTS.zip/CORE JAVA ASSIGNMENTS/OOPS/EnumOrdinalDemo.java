
class EnumOrdinalDemo

{

enum Direction

{

EAST,WEST,NORTH,SOUTH;

}

public static void main(String[] args)
{

for(Direction d:Direction.value())

{
	
System.out.println(d);

}

// System.out.println( "value of: " + Direction.valueof("west"));

System.out.println("value of: " + Direction.valueof("NORTH").ordinal());

}

}

