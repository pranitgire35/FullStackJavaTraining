import java.io.Serializable;
import java.io.*;

class EmployeeDetails implements Serializable

// Scanner sc = new Scaneer();

// sc.nextInt();

{
	private String name;
	
	public void setName(String name)

	{
		this.name=name;
	}

	public String getName()

	{
		return name;
	}

	private String department;
	
	public void setDepartment(String department)

	{
		this.department=department;
	}

	public String getDepartment()

	{
		return department;
	}

	private String designation;
	public void setDesignation(String designation)

	{
		this.designation=designation;
	}

	public String getDesignation()

	{
		return designation;
	}

	private double salary;
	public void setSalary(double salary)

	{
		this.salary=salary;
	}

	public double getSalary()

	{
		return salary;
	}
}

class EmployeeGetterSetter

{
	public static void main(String[] args)

	{
		EmployeeDetails e=new EmployeeDetails();
		
		e.setName("human");
		e.setDesignation("employee");
		e.setDepartment("yashtech");
		e.setSalary(101.0);
		
	    String filename = "Yash.txt";
        
		try 

		{
            FileOutputStream file = new FileOutputStream(filename);
            ObjectOutputStream out = new ObjectOutputStream(file);
            out.writeObject(e);  
            out.close();
            file.close(); 
            System.out.println("before Deserialization.");
			System.out.println(e.getName());
			System.out.println(e.getDepartment());
			System.out.println(e.getDesignation());
			System.out.println(e.getSalary());
		}
        catch (IOException ex) 

		{
            System.out.println("IOException is caught");
        }

        try 

		{    
            FileInputStream file = new FileInputStream(filename);
            ObjectInputStream in = new ObjectInputStream(file);
            e = (EmployeeDetails)in.readObject(); 
            in.close();
            file.close();
            System.out.println("after Deserialization.");
            System.out.println(e.getName());
			System.out.println(e.getDepartment());
			System.out.println(e.getDesignation());
			System.out.println(e.getSalary());       
        }  

		catch (IOException ex) 

		{
            System.out.println("IOException is caught");
        }  

        catch (ClassNotFoundException ex) 

		{
            System.out.println("ClassNotFoundException" + " is caught");
        }
    
		
	}
}