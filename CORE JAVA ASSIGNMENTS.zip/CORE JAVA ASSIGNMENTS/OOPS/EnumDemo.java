public class EnumDemo {
    enum Direction {

        EAST(10), WEST(20), NORTH(30), SOUTH(40);

        int val;

        Direction(int val) {
            this.val = val;
        }

    }

    public static void main(String[] args)

    {

        Direction d = Direction.EAST;

        System.out.println(d);

        for (Direction i : Direction.values())

        {

            System.out.println(i + " " + i.val);

        }
    }
}