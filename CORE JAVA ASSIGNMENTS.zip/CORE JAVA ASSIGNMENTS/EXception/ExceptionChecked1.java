import java.io.FileInputStream;

class ExceptionChecked1

{

public static void main(String[] args)

{

// FileInputStream f = new FileInputStream("D:/xyz.txt);

//file not found(checked)

try

{

//String s = null;

//System.out.println(S.length());

//NullPointerException

System.out.println("hello");

}

catch(Exception e)

{

System.out.println("bye"); //normal termination

//class.forname("com.mysql.jdbc")

}

}
