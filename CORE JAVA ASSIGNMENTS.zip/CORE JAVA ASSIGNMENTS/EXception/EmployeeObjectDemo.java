import java.io.*

class EmployeeObjectDemo

{
public static void main(String[] args) throws exception

{

//Employee e = new Employee(27 , "jaynam");

System.out.println(e);

File f = new File("d:/yash/xyz.txt");

/*objectInputstream ois = new objectInputStream(new FileInputStream(f));

Employee e = (Employee)ois.readObject();

ois.close();

System.out.println(e);*/

objectOutputStream obs = new objectOutputStream(new FileOutputStream(f));

oos.writeObject(e);

oos.close();

}

}
 
