class ExceptionDemo
{

public static void main(String[] args)

{

System.out.println("yash");

System.out.println("technology");

System.out.println("jaynam");

System.out.println(100/0);

System.out.println("bye");

}

}

