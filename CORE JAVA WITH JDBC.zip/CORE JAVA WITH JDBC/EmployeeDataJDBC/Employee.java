package data;

import java.util.*;

public class Employee implements InterfaceShow

   {
	
	String age,mobileNum;
	
	EmployeeInfo employeeinfo;
	
	Employee(String age, String mobileNum)
	
	{
		this.age=age;
		
		this.mobileNum=mobileNum;
		
		Scanner scanner = new Scanner(System.in);
		
			
   //   employeeinfo = new EmployeeInfo(name1,collegeName1,city1,state1,country1); //creating object
	
		
	}
	
	public void display()
	
	{
		
		/*
		 * System.out.println(" Your country is : " +);
		 * 
		 * 
		 * System.out.println("college name is"+employeeinfo.collegeName);
		 * 
		 * 
		 * System.out.println(" Your state is : " +employeeinfo.state);
		 * 
		 * 
		 * System.out.println(" Your city is : "+employeeinfo.city);
		 * 
		 * System.out.println(" Your name is : "+employeeinfo.name);
		 */		
			
	}
		
}

