show databases;

use task;

CREATE TABLE EmployeeInfo(
EmpID INTEGER PRIMARY KEY,
EmpFname VARCHAR(20) NOT NULL,
EmpLname VARCHAR(20) NOT NULL,
Department VARCHAR(10) NOT NULL,
Project VARCHAR(10) NOT NULL,
Address VARCHAR(20) NOT NULL,
DOB date NOT NULL,
Gender VARCHAR(1) NOT NULL
);

CREATE TABLE EmployeePosition(
EmpID INTEGER NOT NULL,
EmpPosition VARCHAR(20) NOT NULL,
DateOfJoining DATE NOT NULL,
SALARY INTEGER NOT NULL
);



INSERT INTO EmployeeInfo VALUES (1, 'Sanjay','Mehra','HR','P1','Hyderabad(HYD)','1976-12-01','M');
INSERT INTO EmployeeInfo VALUES (2, 'Ananya','Mishra','Admin','P2','Delhi(DEL)','1968-05-02','F');
INSERT INTO EmployeeInfo VALUES (3, 'Rohan','Diwan','Account','P3','Mumbai(BOM)','1980-01-01','M');
INSERT INTO EmployeeInfo VALUES (4, 'Sonia','Kulkarni','HR','P1','Hyderabad(HYD)','1992-05-02','F');
INSERT INTO EmployeeInfo VALUES (5, 'Ankit','Kapoor','Admin','P2','Delhi(DEL)','1994-07-03','M');

SELECT * FROM EmployeeInfo;

INSERT INTO EmployeePosition VALUES(1, 'Manager', '2022-05-01',500000);
INSERT INTO EmployeePosition VALUES(2, 'Executive', '2022-05-02',75000);
INSERT INTO EmployeePosition VALUES(3, 'Manager', '2022-05-01',90000);
INSERT INTO EmployeePosition VALUES(2, 'Lead', '2022-05-02',85000);
INSERT INTO EmployeePosition VALUES(1, 'Executive', '2022-05-01',300000);

SELECT * FROM EmployeePosition;


1 SELECT upper(EmpFname) AS EmpName FROM EmployeeInfo;

2 SELECT COUNT(EmpId) FROM EmployeeInfo WHERE Department = 'HR';

3 Query for current date
  SELECT curdate();

4 SELECT substr(EmpLname, 1,4) FROM EmployeeInfo;

5 SELECT MID(Address, 1, locate('(', Address)-1) FROM EmployeeInfo;

6 
CREATE TABLE tempEmployeeInfo SELECT * FROM EmployeeInfo;
SELECT * FROM tempEmployeeInfo;
show tables;

7 
SELECT * FROM EmployeeInfo as ei , EmployeePosition as ep WHERE ei.EmpId = ep.EmpId AND ep.SALARY between 50000 AND 100000;


8 
SELECT EmpFname FROM EmployeeInfo WHERE EmpFname LIKE 'S%';


9 
   SELECT * FROM EmployeeInfo LIMIT 3;

10  
   SELECT CONCAT(EmpFname, CONCAT(' ', EmpLname)) as FullName FROM EmployeeInfo;

11 
SELECT Gender, COUNT(*) FROM EmployeeInfo WHERE DOB BETWEEN '1970-05-02' AND '1975-12-31' GROUP BY Gender;
The query is correct but there is no employee in the given table w/ DOB in given range


12 
    SELECT * FROM EmployeeInfo ORDER BY EmpLname DESC, Department ASC;

13  
    SELECT * FROM EmployeeInfo WHERE EmpLname LIKE '%a' AND LENGTH(EmpLname) = 5;

14 
    SELECT EmpFname FROM EmployeeInfo WHERE EmpFname NOT IN (SELECT EmpFname FROM EmployeeInfo WHERE EmpFname = 'Sanjay' OR EmpFname = 'Sonia');

15  
    SELECT * FROM EmployeeInfo WHERE Address = 'DELHI(DEL)';

16 
    SELECT * FROM EmployeeInfo as ei, EmployeePosition as ep WHERE ei.EmpId = ep.EmpId AND ep.EmpPosition = 'Manager';

17 
    SELECT Department, COUNT(*) FROM EmployeeInfo group by Department ORDER BY Department;

18 

SELECT * FROM EmployeeInfo WHERE EmpId % 2 = 0;
Odd records
SELECT * FROM EmployeeInfo WHERE EmpId % 2 = 1;

19  SELECT * FROM EmployeeInfo WHERE EmpId IN (SELECT EmpId FROM EmployeePosition);

20  SELECT SALARY FROM EmployeePosition ORDER BY Salary LIMIT 2;
    Maximum 2
    SELECT SALARY FROM EmployeePosition ORDER BY Salary DESC LIMIT 2;

21  SELECT  Salary FROM EmployeePosition as ep1 WHERE 0 = (SELECT COUNT(Salary) FROM EmployeePosition as ep2 WHERE ep2.Salary > ep1.Salary);

22  SELECT * FROM EmployeeInfo GROUP by EmpID HAVING COUNT(EmpId) > 1;

23  SELECT * FROM EmployeeInfo ORDER BY Department;

24  SELECT * FROM EmployeeInfo ORDER BY EmpID DESC LIMIT 3;

25 SELECT SALARY FROM EmployeePosition as ep1 WHERE 2 = (SELECT COUNT(*) FROM EmployeePosition as ep2 WHERE ep2.Salary > ep1.Salary);
