package com.automobile;

public class Honda extends Vehicle 
{
	public int getSpeed()
		{ 
			return 100;
		}

		public void radio()
		{ 
			System.out.println("Radio");
		}
		public String getModelName()
		{
		 return "Honda";	
		}
		public String getRegistrationumber()
		{
			return "4432";
			
		}
		public String getOwnerName()
		{
			return "Shefali";
		}


}