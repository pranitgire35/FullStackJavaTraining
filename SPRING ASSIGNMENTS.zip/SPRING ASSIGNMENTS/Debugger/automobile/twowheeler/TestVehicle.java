package com.automobile.twowe;

public class TestVehicle {
           public static void main(String args[])
           {
        	   Honda h=new Honda();
        	   System.out.println(h.getSpeed());
           }
}