package com.automobile.twowheeler;

import com.automobile.Vehicle;

public class Hero extends Vehicle 
{
	public int getSpeed()
		{ 
			return 100;
		}

		public void radio()
		{ 
			System.out.println("Radio");
		}
		public String getModelName()
		{
		 return "Hero";	
		}
		public String getRegistrationumber()
		{
			return "4432";
			
		}
		public String getOwnerName()
		{
			return "Shefali";
		}
	
}