package Com.yash.debugger;

import java.util.Scanner;

public class ExceptionTest1 

{

	public static void main(String[] args)

	{
	
	 int in , avg = 0;
	 
	 Scanner sc = new Scanner(System.in);
	 
	 System.out.println("enter the size and number of array");
	 
	 int n=sc.nextInt();
	 
	 int []a = new int[n];
	 
	 for(int i = 0; i < n ; i++)
	 
	 {
		 a[i] = sc.nextInt(); 
	 }
	 
	 System.out.println("enter the index");
			 
	 in = sc.nextInt();
	 
	 try
	 
	 {
		String  str  = null;
		
		System.out.println(a[in]);
		
		avg = 3/0;
		
		System.out.println(avg);
		
	 }
	 
	 catch(NullPointerException e)
	 
	 {
		 System.out.println(e);
		 
	 }
		
	 catch(ArithmeticException e)
	
	 {
		 System.out.println(e);
	 }
	 
	 catch(ArrayIndexOutOfBoundsException e)
	
	 {
		 System.out.println(e);
	 }
	 
	 catch(NumberFormatException e)
	 
	 {
		 System.out.println(e);
	 }
	 
	 System.out.println("end of our program");
	 
    }

}