package Com.yash.debugger;

public class DebuggerDemo1 

{
   public static void main(String[] args)
  
   {
	   System.out.println("welcome to yash");
	   
//	   int i = 100;
//	  
//	   // show();
//	   
//	   if(i<120)
//		   
//	   {
//		   System.out.println("i is lesser");
//	   }
//	   
   }
   
   
	
}
