package newpackage;

class A{}

interface b{}

public class DemoForName 

{
  public static void main(String[] args) throws ClassNotFoundException
  
  {
	  
	  Class c = Class.forName("A");
	  
	  System.out.println(c.isInterface());
	  
	  Class c1= Class.forName("b");
	  
	  System.out.println(c1.isInterface());
	  
	  
	  
  }
	
	
	
}
