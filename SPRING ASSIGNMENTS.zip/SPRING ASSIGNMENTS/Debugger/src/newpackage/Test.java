package newpackage;

public class Test 

{

    public void firstMoveChoice()
	
	{
        System.out.println("First Move");
    } 
    
	public void secondMOveChoice()
	
	{
        System.out.println("Second Move");
    }
    

    public static void main(String[] args)
	
	{ 
      
	    Test test = new Test();
        
		Method[] method = test.getClass().getMethods();
       
        method[0].invoke(test, null);
       
        method[1].invoke(test, null);
    
	}

}