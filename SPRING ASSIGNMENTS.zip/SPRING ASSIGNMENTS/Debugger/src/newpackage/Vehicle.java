package Com.yash.debugger;

public class Vehicle 

{

	
	
}
