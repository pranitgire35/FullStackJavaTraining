class new

{

public static void main(String[] args)

{

System.out.println("jay Ganesh");

}

}
