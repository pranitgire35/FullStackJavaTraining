
import org.springframework.beans.factory.BeanFactory;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

    public static void main(String[] args) {
        
    	BeanFactory beanFactory = new ClassPathXmlApplicationContext("applicationcontext.xml");
      
        Employee employee = (Employee) beanFactory.getBean("employee");
        
        System.out.println("employee Id : " + employee.getEmployeeId());
        
        System.out.println("employee Name : " + employee.getEmployeeName());
    }
}
