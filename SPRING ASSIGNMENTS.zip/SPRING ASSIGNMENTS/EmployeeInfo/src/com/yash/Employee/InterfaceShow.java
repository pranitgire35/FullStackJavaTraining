package com.yash.Employee;

 interface InterfaceShow 

{
	 void display();	
}
