package com.yash.Employee;

import java.util.*;

import com.yash.Employeeinformation.EmployeeInfo;

public class Employee implements InterfaceShow

   {
	
	String age,mobileNum;
	
	EmployeeInfo employeeinfo;
	
	public Employee(String age, String mobileNum)
	
	{
		this.age=age;
		
		this.mobileNum=mobileNum;
		
		Scanner scanner = new Scanner(System.in);	
		
	}
	
	public void display()
	
	{
		
		/*
		 * System.out.println(" Your country is : " +);
		 * 
		 * 
		 * System.out.println("college name is"+employeeinfo.collegeName);
		 * 
		 * 
		 * System.out.println(" Your state is : " +employeeinfo.state);
		 * 
		 * 
		 * System.out.println(" Your city is : "+employeeinfo.city);
		 * 
		 * System.out.println(" Your name is : "+employeeinfo.name);
		 */		
			
	}
		
}

