package com.yash.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.yash.Employee.Employee;
import com.yash.Employeeinformation.EmployeeInfo;
import com.yash.sallaryinfo.SallaryInfo;

public class Main 

{
    public static void main(String[] args) throws SQLException
	
	{
		 try 
				{
		
	    Connection con=null;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter your Age : ");     
	    
	    String age =scanner.nextLine();
	    
        System.out.println("\nEnter your Mobile Number : ");
	    
	    String mobileNumber =scanner.nextLine();
	    
	    System.out.println("\nEnter Your Travelling Allowance : ");
	    
	    String travellingAllowance = scanner.nextLine();
	    
        int travel = Integer.parseInt(travellingAllowance);
	    	    
        System.out.println("\nEnter Your Overtime : ");
	    
        String overtime = scanner.nextLine();
        
        int convert = Integer.parseInt(overtime);
	    
	    int AdditionofAllowance = travel + convert;
	    
	 SallaryInfo salleryinfoObj = new SallaryInfo();
	 
	 salleryinfoObj.setOverTime(overtime);
	 
	 salleryinfoObj.setTravellingAllowance(travellingAllowance);
	 
	 String getovertime = salleryinfoObj.getOverTime();
	 
	 String gettravellingallowance = salleryinfoObj.getTravellingAllowance();
	 
     System.out.println("\nEnter Your id : ");
        
     String id=scanner.nextLine();
		 
     System.out.println("\nEnter Your First Name : ");
	    
     String name=scanner.nextLine();
        
	 System.out.println("\nEnter Your Company Name : ");
		
	    String collegeName=scanner.nextLine();
	    
		System.out.println("\nEnter Your City Name : ");
		
		String city=scanner.nextLine();
		
		System.out.println("\nEnter Your State Name : ");
		
		String state=scanner.nextLine();
	    
		System.out.println("\nEnter Your Country Name : ");
	    
		String country=scanner.nextLine();
	    
		Employee employee = new Employee(age, mobileNumber);
		
		EmployeeInfo employeeinfo = new EmployeeInfo();
		
		employeeinfo.setId(id);
		employeeinfo.setName(name);
		employeeinfo.setCity(city);
		employeeinfo.setCollegeName(collegeName);
		employeeinfo.setState(state);
		employeeinfo.setCountry(country);
		
	 /****************************DATABASE CODE*********************************/

		   //drver load
		
		    Class.forName("com.mysql.cj.jdbc.Driver");
			
		  //connection bridge
		    
			String url ="jdbc:mysql://localhost:3306/employeedata";
			
			String user="root";
			
			String pass="root";
			
			con=DriverManager.getConnection(url,user,pass);
			 
	        System.out.println("\nCreated Table In Given Database...");
	        
	      //value set query
	        
	        PreparedStatement st = con.prepareStatement("Insert Into details Values(?,?,?)");
	    	
	        st.setString(1, employeeinfo.getId()); 
	        st.setString(2,employeeinfo.getName());
	        st.setString(3,employeeinfo.getCollegeName());
	        st.executeUpdate();
	        
	         employee.display(); 
			    
		     PreparedStatement stt = con.prepareStatement("Insert Into address Values(?,?,?)");
	         
		     stt.setString(1, employeeinfo.getCity()); 
	         stt.setString(2, employeeinfo.getState());
	         stt.setString(3, employeeinfo.getCountry());
	         stt.executeUpdate();
	         
	         
		     PreparedStatement sttt = con.prepareStatement("Insert Into otherinformation Values(?,?,?,?,?)");
	        
		     sttt.setString(1,age);
	         sttt.setString(2, mobileNumber);
	         sttt.setString(3, travellingAllowance);
	         sttt.setString(4, overtime);       
	         sttt.setInt(5, AdditionofAllowance);
	         sttt.executeUpdate();
	         
	         //to store value 
	        
	         
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}

