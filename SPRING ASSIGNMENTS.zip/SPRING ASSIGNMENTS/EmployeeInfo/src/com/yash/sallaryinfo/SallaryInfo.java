package com.yash.sallaryinfo;

public class SallaryInfo 

{

    private String travellingAllowance ,overtime;

  
	public void setTravellingAllowance(String travellingAllowance) 
	
	{
		this.travellingAllowance = travellingAllowance;
	}

	public String getTravellingAllowance()
	
	{
		return travellingAllowance;
	}
	
	public void setOverTime(String overTime)
	
	{
		this.overtime=overtime;
	}
	
	public String getOverTime()
	
	{
		return overtime;
	}
 	
}
