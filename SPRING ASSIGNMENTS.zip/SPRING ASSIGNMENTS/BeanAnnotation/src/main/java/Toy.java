



import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;



import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;



public class Toy /*implements InitializingBean, DisposableBean*/{

private String name;

public Toy(String name) {
super();
this.name = name;
}



public void play() {
System.out.println(this.name + " is Playing");
}



// Using IntializingBean, DisposableBean Interface to initialize and destroy a bean
/*
public void afterPropertiesSet() throws Exception {
// TODO Auto-generated method stub
System.out.println("Bean intialized using IntializingBean interface");
}



public void destroy() throws Exception {
// TODO Auto-generated method stub
System.out.println("Bean destroyed using DisposableBean interface");
}*/


/*
* XML Based Bean initializing and destruction methods
public void init() {
System.out.println("Intializing Bean");
}

public void destroy() {
System.out.println("Closing container and destroying bean");
}
*/

@PostConstruct
public void init() {
System.out.println("Intializing Bean using annotation");
}

@PreDestroy
public void destroy() {
System.out.println("Closing container and destroying bean");
}
}