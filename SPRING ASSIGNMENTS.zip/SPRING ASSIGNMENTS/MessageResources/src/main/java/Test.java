
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args)
	
	{
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationcontext.xml");
		
		String m = context.getMessage("message", null, "Default Message", null);
		
		System.out.println(m);
		
	}

}
