import java.util.Locale;


import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;

public class Toy{
	
	private String name;
	
	public Toy(String name) {
		super();
		this.name = name;
	}

	public void play() {
		System.out.println(this.name + " is Playing");
	}
}
