package data;

 interface InterfaceShow 

{
	 void display();	
}
