  

public class Employee

{  

private int id;  
private String name;  
private float salary;  
//no-arg and parameterized constructors  
//getters and setters  

public String toString()

{  
    return id+" "+name+" "+salary;  
 
}  

}  