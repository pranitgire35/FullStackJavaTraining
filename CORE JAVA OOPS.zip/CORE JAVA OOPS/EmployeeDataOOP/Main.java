package com;

import java.util.Scanner;

public class Main 

{
	
	public static void main(String []args)
	
	
	{
		
		Scanner sa=new Scanner(System.in);
		
		System.out.println("Enter your Name : ");
		String name=sa.nextLine();
		
		System.out.println("Enter collage Name : ");
		String Cname=sa.nextLine();
		
		
		EMP ep=new EMP( name ,Cname);
		
		ep.show();
		
		//***************************************************************************
		//Encapsulation of sallary class..
		 
		System.out.println("Enter Traveling Allowance : ");
		String tr=sa.nextLine();
		
		System.out.println("Enter Collage Travel : ");
		String td=sa.nextLine();
		
		System.out.println("Enter Collage Overtime : ");
		
		String ot=sa.nextLine();
		
		Sallary ss=new Sallary();
		
		ss.setTr(tr);
		ss.setTd(td);
		ss.setOt(ot);
		
		String trav=ss.getTr();
		String daytime=ss.getTd();
		String overtime=ss.getOt();
		
		//Addition of traveling..
		
		int t,d,o,i;
		
		t=Integer.parseInt(trav);
		
		d=Integer.parseInt(daytime);
		
		o=Integer.parseInt(overtime);
		
		i=t+d+o;
		
		System.out.println( "\nEmployee Name Is : "+name+ " \nEmployee Collage Name Is : " +Cname);
		
		System.out.println("\nTotal Rupees Are = " +i);
		
	    
		//	sa1=new Sallary(tr,td,ot);  // Composition used  
		//This block is reffer to the Sallary input
		
       
		
	}
	

}

