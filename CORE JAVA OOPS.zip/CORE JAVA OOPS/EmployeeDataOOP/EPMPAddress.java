
package com;

public class EPMPAddress 

{
	
 String city,state,country;
 
 EPMPAddress(String city ,String state,String country )
 
 
 {

	 this.city=city;
	 this.state=state;
	 this.country=country; 
	 
	 
	 // this is the emp address and this keyword show the value of local variable and pass to the instance variable

 }
 

}
