package com;

public class Sallary 

{
	// Encapsulation class of sallary
	
	private String tr,td,ot;

	public String getTr() {
		return tr;
	}

	public void setTr(String tr) {
		this.tr = tr;
	}

	public String getTd() {
		return td;
	}

	public void setTd(String td) {
		this.td = td;
	}

	public String getOt() {
		return ot;
	}

	public void setOt(String ot) {
		this.ot = ot;
	}
	
	
	// he comment aggression.sati ahe...hyacha upyog aggression.sati kela ahe ....te kadhu naka
//	Sallary(String tr,String td,String ot)
//	
//	{
//		//this.tr=tr;
//		//this.td=td;
//		//this.ot=ot;
//		
//		
//	}
	
	//this keyword show the value of local variable pass to the instance variable

}
