package com;

import java.util.Scanner;

public class EMP implements Interfaceclass

   {
	
	String name, collagename;
	EPMPAddress dr;  // Aggregation of Address class 
	Sallary sa1;    // Aggregation of Sallary class

	//Constructor
	
	EMP(String name, String collagename)
	
	{
        this.name=name;
		this.collagename=collagename;
	
		//This block is reffer to the EMPAddress input	
		
        Scanner sa=new Scanner(System.in);  		
	    
        System.out.println("Enter your city : ");
		String city=sa.nextLine();
		
		System.out.println("Enter collage state : ");
		String state=sa.nextLine();
		
		System.out.println("Enter collage counrty : ");
		String country=sa.nextLine();
		
		
		
		   //This is the Compossition 
		
		dr=new EPMPAddress(city,state,country); 	
		
	}
	   	      	
public void show()
	
	{
		
		System.out.println("\nCity Name Is : "+dr.city);

		System.out.println("State Name Is : "+dr.state);
		
		System.out.println("Country Name Is : "+dr.country);
		
//		System.out.println("Overtime amount is "+sa1.ot);
//		
//		System.out.println("Collage name is "+sa1.td);
//		
//		System.out.println("Collage name is "+sa1.tr);
	
	}
	
}


