package com;

public interface  Interfaceclass

{
 
	void show();

}

