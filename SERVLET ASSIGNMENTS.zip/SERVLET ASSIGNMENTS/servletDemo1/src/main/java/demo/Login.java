package demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Login extends HttpServlet {
	   
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	response.setContentType("text/html");
	
	PrintWriter out =response.getWriter();
	
	String n = request.getParameter("name");
	
	String p = request.getParameter("password");
	
	HttpSession hs = request.getSession(true);
	
	hs.setAttribute("names", n);
 
	hs.setAttribute("pass", p);
	
	out.println("<html> <head> </head> <body> <form action= \"./Login1.java\" method=\"post\"> age : <input type=\"text\" name=\"age\" palceholder=\"enter your age\">");
	
	out.println("<input type=\"submit\" value=\"submit\" > </form>  </body> </html>");
			
//	out.println(" " + n  + " " + p);
	
	}

}
