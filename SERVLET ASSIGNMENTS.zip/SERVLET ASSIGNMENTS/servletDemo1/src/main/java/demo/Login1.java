package demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login1
 */
public class Login1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
	   
		response.setContentType("text/html");
		
		PrintWriter out =response.getWriter();
		
		String a = request.getParameter("age");
		
		HttpSession hs = request.getSession(false);
		
	   String p1 =(String) hs.getAttribute("names");
		
	   String p2 =(String) hs.getAttribute("pass");
	   
	   out.println(p1 + " " +  " " + p2 + " " + a);

		
	
	}

}
