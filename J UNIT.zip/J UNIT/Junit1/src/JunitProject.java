import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class JunitProject 

{

	@Test
	
	public void test_junit()
	{
		System.out.println("lets check this string");
		
		String str1 = "lets check this string1";    //when string change into string1 test case 
		
		//is faild beacause of assertion input not matches the expected output
		
		assertEquals("lets check this string", str1);
	}
	
}
