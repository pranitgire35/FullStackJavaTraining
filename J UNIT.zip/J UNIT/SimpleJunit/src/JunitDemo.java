import org.junit.Test;

public class JunitDemo {

	@Test
	
	public void junitMethod()
	
	{
		System.out.println("Executing junit test cases");
	}
	
	
	
	public static void main(String[] args)
	
	{
		
	// TODO Auto-generated method stub
		
	}

}
