import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class Test1 

{

	String message = "TestPass";
	
	@Test
	
	public void testPrintMessage()
	{
		System.out.println("Inside testPrintMessage()");
		
		assertEquals(message, "TestPass");
	}
	
	public static void main(String[] args)
	{
	   Test1 result = new Test1();
	   result.testPrintMessage();
	}
}
